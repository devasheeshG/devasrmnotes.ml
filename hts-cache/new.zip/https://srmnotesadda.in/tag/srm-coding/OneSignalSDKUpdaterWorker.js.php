<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">
<title>Page not found &#8211; SRMnotesADDA</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='//jetpack.wordpress.com' />
<link rel='dns-prefetch' href='//s0.wp.com' />
<link rel='dns-prefetch' href='//public-api.wordpress.com' />
<link rel='dns-prefetch' href='//0.gravatar.com' />
<link rel='dns-prefetch' href='//1.gravatar.com' />
<link rel='dns-prefetch' href='//2.gravatar.com' />
<link rel='dns-prefetch' href='//c0.wp.com' />
<link rel="alternate" type="application/rss+xml" title="SRMnotesADDA &raquo; Feed" href="https://srmnotesadda.in/feed/" />
<link rel="alternate" type="application/rss+xml" title="SRMnotesADDA &raquo; Comments Feed" href="https://srmnotesadda.in/comments/feed/" />
<script type="text/javascript">
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/14.0.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/srmnotesadda.in\/wp-includes\/js\/wp-emoji-release.min.js?ver=6.1.1"}};
/*! This file is auto-generated */
!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode,e=(p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0),i.toDataURL());return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(p&&p.fillText)switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([129777,127995,8205,129778,127999],[129777,127995,8203,129778,127999])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(e=t.source||{}).concatemoji?c(e.concatemoji):e.wpemoji&&e.twemoji&&(c(e.twemoji),c(e.wpemoji)))}(window,document,window._wpemojiSettings);
</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 0.07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://c0.wp.com/c/6.1.1/wp-includes/css/dist/block-library/style.min.css' type='text/css' media='all' />
<style id='wp-block-library-inline-css' type='text/css'>
.has-text-align-justify{text-align:justify;}
</style>
<link rel='stylesheet' id='mediaelement-css' href='https://c0.wp.com/c/6.1.1/wp-includes/js/mediaelement/mediaelementplayer-legacy.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='wp-mediaelement-css' href='https://c0.wp.com/c/6.1.1/wp-includes/js/mediaelement/wp-mediaelement.min.css' type='text/css' media='all' />
<link rel='stylesheet' id='classic-theme-styles-css' href='https://c0.wp.com/c/6.1.1/wp-includes/css/classic-themes.min.css' type='text/css' media='all' />
<style id='global-styles-inline-css' type='text/css'>
body{--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--color--neve-link-color: var(--nv-primary-accent);--wp--preset--color--neve-link-hover-color: var(--nv-secondary-accent);--wp--preset--color--nv-site-bg: var(--nv-site-bg);--wp--preset--color--nv-light-bg: var(--nv-light-bg);--wp--preset--color--nv-dark-bg: var(--nv-dark-bg);--wp--preset--color--neve-text-color: var(--nv-text-color);--wp--preset--color--nv-text-dark-bg: var(--nv-text-dark-bg);--wp--preset--color--nv-c-1: var(--nv-c-1);--wp--preset--color--nv-c-2: var(--nv-c-2);--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');--wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');--wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');--wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');--wp--preset--duotone--midnight: url('#wp-duotone-midnight');--wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');--wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');--wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;}:where(.is-layout-flex){gap: 0.5em;}body .is-layout-flow > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-flow > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-flow > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignleft{float: left;margin-inline-start: 0;margin-inline-end: 2em;}body .is-layout-constrained > .alignright{float: right;margin-inline-start: 2em;margin-inline-end: 0;}body .is-layout-constrained > .aligncenter{margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > :where(:not(.alignleft):not(.alignright):not(.alignfull)){max-width: var(--wp--style--global--content-size);margin-left: auto !important;margin-right: auto !important;}body .is-layout-constrained > .alignwide{max-width: var(--wp--style--global--wide-size);}body .is-layout-flex{display: flex;}body .is-layout-flex{flex-wrap: wrap;align-items: center;}body .is-layout-flex > *{margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
.wp-block-navigation a:where(:not(.wp-element-button)){color: inherit;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}
.wp-block-pullquote{font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='adfoxly-adfoxly-public-css' href='https://srmnotesadda.in/wp-content/plugins/adfoxly/public/css/adfoxly-public.css?ver=1.7.91' type='text/css' media='all' />
<link rel='stylesheet' id='wpfront-scroll-top-css' href='https://srmnotesadda.in/wp-content/plugins/wpfront-scroll-top/css/wpfront-scroll-top.min.css?ver=2.0.7.08086' type='text/css' media='all' />
<link rel='stylesheet' id='ez-toc-css' href='https://srmnotesadda.in/wp-content/plugins/easy-table-of-contents/assets/css/screen.min.css?ver=6.1.1' type='text/css' media='all' />
<style id='ez-toc-inline-css' type='text/css'>
div#ez-toc-container p.ez-toc-title {font-size: 120%;}div#ez-toc-container p.ez-toc-title {font-weight: 500;}div#ez-toc-container ul li {font-size: 95%;}div#ez-toc-container nav ul ul li ul li {font-size: %!important;}
.ez-toc-container-direction {
    direction: ltr;
}

	.ez-toc-counter ul {
	    counter-reset: item;
	}


	
	.ez-toc-counter nav ul li a::before {
	    content: counters(item, ".", decimal) ". ";
	    display: inline-block;
	    counter-increment: item;
        flex-grow: 0;
        flex-shrink: 0;
	    margin-right: .2em; 

	    float: left;
	}


.ez-toc-widget-direction {
    direction: ltr;
}

	.ez-toc-widget-container ul {
	    counter-reset: item;
	}


	
	.ez-toc-widget-container nav ul li a::before {
	    content: counters(item, ".", decimal) ". ";
	    display: inline-block;
	    counter-increment: item;
        flex-grow: 0;
        flex-shrink: 0;
	    margin-right: .2em; 

	    float: left;
	}


</style>
<link rel='stylesheet' id='neve-style-css' href='https://srmnotesadda.in/wp-content/themes/neve/assets/css/style-legacy.min.css?ver=3.4.4' type='text/css' media='all' />
<style id='neve-style-inline-css' type='text/css'>
.header-menu-sidebar-inner li.menu-item-nav-search { display: none; }
		[data-row-id] .row { display: flex !important; align-items: center; flex-wrap: unset;}
		@media (max-width: 960px) { .footer--row .row { flex-direction: column; } }
.nv-meta-list li.meta:not(:last-child):after { content:"/" }.nv-meta-list .no-mobile{
			display:none;
		}.nv-meta-list li.last::after{
			content: ""!important;
		}@media (min-width: 769px) {
			.nv-meta-list .no-mobile {
				display: inline-block;
			}
			.nv-meta-list li.last:not(:last-child)::after {
		 		content: "/" !important;
			}
		}
 .container{ max-width: 987px; } .has-neve-button-color-color{ color: var(--nv-primary-accent)!important; } .has-neve-button-color-background-color{ background-color: var(--nv-primary-accent)!important; } .single-post-container .alignfull > [class*="__inner-container"], .single-post-container .alignwide > [class*="__inner-container"]{ max-width:957px } .button.button-primary, button, input[type=button], .btn, input[type="submit"], /* Buttons in navigation */ ul[id^="nv-primary-navigation"] li.button.button-primary > a, .menu li.button.button-primary > a, .wp-block-button.is-style-primary .wp-block-button__link, .wc-block-grid .wp-block-button .wp-block-button__link, form input[type="submit"], form button[type="submit"]{ background-color: var(--nv-primary-accent);color: #ffffff;border-radius:3px 3px 3px 3px;border:none;border-width:1px 1px 1px 1px; } .button.button-primary:hover, ul[id^="nv-primary-navigation"] li.button.button-primary > a:hover, .menu li.button.button-primary > a:hover, .wp-block-button.is-style-primary .wp-block-button__link:hover, .wc-block-grid .wp-block-button .wp-block-button__link:hover, form input[type="submit"]:hover, form button[type="submit"]:hover{ background-color: var(--nv-primary-accent);color: #ffffff; } .button.button-secondary:not(.secondary-default), .wp-block-button.is-style-secondary .wp-block-button__link{ background-color: var(--nv-primary-accent);color: #ffffff;border-radius:3px 3px 3px 3px;border:none;border-width:1px 1px 1px 1px; } .button.button-secondary.secondary-default{ background-color: var(--nv-primary-accent);color: #ffffff;border-radius:3px 3px 3px 3px;border:none;border-width:1px 1px 1px 1px; } .button.button-secondary:not(.secondary-default):hover, .wp-block-button.is-style-secondary .wp-block-button__link:hover{ background-color: var(--nv-primary-accent);color: #ffffff; } .button.button-secondary.secondary-default:hover{ background-color: var(--nv-primary-accent);color: #ffffff; } form input:read-write, form textarea, form select, form select option, form.wp-block-search input.wp-block-search__input, .widget select{ color: var(--nv-text-color); } form.search-form input:read-write{ padding-right:45px !important; } .global-styled{ --bgcolor: var(--nv-site-bg); } .header-top-inner,.header-top-inner a:not(.button),.header-top-inner .navbar-toggle{ color: var(--nv-text-color); } .header-top-inner .nv-icon svg,.header-top-inner .nv-contact-list svg{ fill: var(--nv-text-color); } .header-top-inner .icon-bar{ background-color: var(--nv-text-color); } .hfg_header .header-top-inner .nav-ul .sub-menu{ background-color: var(--nv-site-bg); } .hfg_header .header-top-inner{ background-color: var(--nv-site-bg); } .header-bottom-inner,.header-bottom-inner a:not(.button),.header-bottom-inner .navbar-toggle{ color: var(--nv-text-color); } .header-bottom-inner .nv-icon svg,.header-bottom-inner .nv-contact-list svg{ fill: var(--nv-text-color); } .header-bottom-inner .icon-bar{ background-color: var(--nv-text-color); } .hfg_header .header-bottom-inner .nav-ul .sub-menu{ background-color: var(--nv-site-bg); } .hfg_header .header-bottom-inner{ background-color: var(--nv-site-bg); } .header-menu-sidebar .header-menu-sidebar-bg,.header-menu-sidebar .header-menu-sidebar-bg a:not(.button),.header-menu-sidebar .header-menu-sidebar-bg .navbar-toggle{ color: var(--nv-text-color); } .header-menu-sidebar .header-menu-sidebar-bg .nv-icon svg,.header-menu-sidebar .header-menu-sidebar-bg .nv-contact-list svg{ fill: var(--nv-text-color); } .header-menu-sidebar .header-menu-sidebar-bg .icon-bar{ background-color: var(--nv-text-color); } .hfg_header .header-menu-sidebar .header-menu-sidebar-bg .nav-ul .sub-menu{ background-color: var(--nv-site-bg); } .hfg_header .header-menu-sidebar .header-menu-sidebar-bg{ background-color: var(--nv-site-bg); } .header-menu-sidebar{ width: 360px; } .builder-item--logo .site-logo img{ max-width: 120px; } .builder-item--logo .site-logo{ padding:10px 0px 10px 0px; } .builder-item--logo{ margin:0px 0px 0px 0px; } .builder-item--nav-icon .navbar-toggle{ padding:6px 6px 6px 6px; } .builder-item--nav-icon{ margin:0px 0px 0px 0px; } .builder-item--primary-menu .nav-menu-primary > .nav-ul li:not(.woocommerce-mini-cart-item) > a,.builder-item--primary-menu .nav-menu-primary > .nav-ul .has-caret > a,.builder-item--primary-menu .nav-menu-primary > .nav-ul .neve-mm-heading span,.builder-item--primary-menu .nav-menu-primary > .nav-ul .has-caret{ color: #f50000; } .builder-item--primary-menu .nav-menu-primary > .nav-ul li:not(.woocommerce-mini-cart-item) > a:after,.builder-item--primary-menu .nav-menu-primary > .nav-ul li > .has-caret > a:after{ background-color: #ffd6d6; } .builder-item--primary-menu .nav-menu-primary > .nav-ul li.current-menu-item > a,.builder-item--primary-menu .nav-menu-primary > .nav-ul li.current_page_item > a,.builder-item--primary-menu .nav-menu-primary > .nav-ul li.current_page_item > .has-caret > a{ color: #000000; } .builder-item--primary-menu .nav-menu-primary > .nav-ul li.current-menu-item > .has-caret svg{ fill: #000000; } .builder-item--primary-menu .nav-ul > li:not(:last-of-type){ margin-right:20px; } .builder-item--primary-menu .style-full-height .nav-ul li:not(.menu-item-nav-search):not(.menu-item-nav-cart):hover > a:after{ width: calc(100% + 20px); } .builder-item--primary-menu .nav-ul li a, .builder-item--primary-menu .neve-mm-heading span{ min-height: 25px; } .builder-item--primary-menu{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px; font-weight: 500; text-transform: none;padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } .builder-item--primary-menu svg{ width: 1em;height: 1em; } .builder-item--header_search_responsive a.nv-search.nv-icon > svg{ width: 20px;height: 20px;fill: #000000; } .builder-item--header_search_responsive a.nv-search.nv-icon:hover > svg{ fill: #ff0000; } .builder-item--header_search_responsive input[type=submit],.builder-item--header_search_responsive .nv-search-icon-wrap{ width: 14px; } .builder-item--header_search_responsive .nv-nav-search .search-form input[type=search]{ height: 40px; font-size: 14px;padding-right:50px;border-width:1px 1px 1px 1px;border-radius:1px 1px 1px 1px; } .builder-item--header_search_responsive .nv-search-icon-wrap .nv-icon svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive .close-responsive-search svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive{ padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } .footer-bottom-inner{ background-color: var(--nv-site-bg); } .footer-bottom-inner,.footer-bottom-inner a:not(.button),.footer-bottom-inner .navbar-toggle{ color: #ffffff; } .footer-bottom-inner .nv-icon svg,.footer-bottom-inner .nv-contact-list svg{ fill: #ffffff; } .footer-bottom-inner .icon-bar{ background-color: #ffffff; } .footer-bottom-inner .nav-ul .sub-menu{ background-color: var(--nv-site-bg); } .nav-menu-footer #footer-menu > li > a{ color: #ffffff; } #footer-menu > li > a:after{ background-color: #b6b6b6; } .nav-menu-footer:not(.style-full-height) #footer-menu > li:hover > a{ color: #b6b6b6; } .builder-item--footer-menu .nav-ul > li:not(:last-of-type){ margin-right:20px; } .builder-item--footer-menu .style-full-height .nav-ul#footer-menu > li:hover > a:after{ width: calc(100% + 20px); } .builder-item--footer-menu .nav-ul a{ min-height: 25px; } .builder-item--footer-menu li > a{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px; font-weight: 500; text-transform: none; } .builder-item--footer-menu li > a svg{ width: 1em;height: 1em; } .builder-item--footer-menu{ padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } @media(min-width: 576px){ .container{ max-width: 992px; } .single-post-container .alignfull > [class*="__inner-container"], .single-post-container .alignwide > [class*="__inner-container"]{ max-width:962px } .header-menu-sidebar{ width: 360px; } .builder-item--logo .site-logo img{ max-width: 120px; } .builder-item--logo .site-logo{ padding:10px 0px 10px 0px; } .builder-item--logo{ margin:0px 0px 0px 0px; } .builder-item--nav-icon .navbar-toggle{ padding:10px 15px 10px 15px; } .builder-item--nav-icon{ margin:0px 0px 0px 0px; } .builder-item--primary-menu .nav-ul > li:not(:last-of-type){ margin-right:20px; } .builder-item--primary-menu .style-full-height .nav-ul li:not(.menu-item-nav-search):not(.menu-item-nav-cart):hover > a:after{ width: calc(100% + 20px); } .builder-item--primary-menu .nav-ul li a, .builder-item--primary-menu .neve-mm-heading span{ min-height: 25px; } .builder-item--primary-menu{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px;padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } .builder-item--primary-menu svg{ width: 1em;height: 1em; } .builder-item--header_search_responsive input[type=submit],.builder-item--header_search_responsive .nv-search-icon-wrap{ width: 14px; } .builder-item--header_search_responsive .nv-nav-search .search-form input[type=search]{ height: 40px; font-size: 14px;padding-right:50px;border-width:1px 1px 1px 1px;border-radius:1px 1px 1px 1px; } .builder-item--header_search_responsive .nv-search-icon-wrap .nv-icon svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive .close-responsive-search svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive{ padding:0px 10px 0px 10px;margin:0px 0px 0px 0px; } .builder-item--footer-menu .nav-ul > li:not(:last-of-type){ margin-right:20px; } .builder-item--footer-menu .style-full-height .nav-ul#footer-menu > li:hover > a:after{ width: calc(100% + 20px); } .builder-item--footer-menu .nav-ul a{ min-height: 25px; } .builder-item--footer-menu li > a{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px; } .builder-item--footer-menu li > a svg{ width: 1em;height: 1em; } .builder-item--footer-menu{ padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } }@media(min-width: 960px){ .container{ max-width: 1170px; } body:not(.single):not(.archive):not(.blog):not(.search):not(.error404) .neve-main > .container .col, body.post-type-archive-course .neve-main > .container .col, body.post-type-archive-llms_membership .neve-main > .container .col{ max-width: 70%; } body:not(.single):not(.archive):not(.blog):not(.search):not(.error404) .nv-sidebar-wrap, body.post-type-archive-course .nv-sidebar-wrap, body.post-type-archive-llms_membership .nv-sidebar-wrap{ max-width: 30%; } .neve-main > .archive-container .nv-index-posts.col{ max-width: 70%; } .neve-main > .archive-container .nv-sidebar-wrap{ max-width: 30%; } .neve-main > .single-post-container .nv-single-post-wrap.col{ max-width: 70%; } .single-post-container .alignfull > [class*="__inner-container"], .single-post-container .alignwide > [class*="__inner-container"]{ max-width:789px } .container-fluid.single-post-container .alignfull > [class*="__inner-container"], .container-fluid.single-post-container .alignwide > [class*="__inner-container"]{ max-width:calc(70% + 15px) } .neve-main > .single-post-container .nv-sidebar-wrap{ max-width: 30%; } .header-menu-sidebar{ width: 360px; } .builder-item--logo .site-logo img{ max-width: 279px; } .builder-item--logo .site-logo{ padding:0px 0px 0px 0px; } .builder-item--logo{ margin:0px 0px 0px 0px; } .builder-item--nav-icon .navbar-toggle{ padding:10px 15px 10px 15px; } .builder-item--nav-icon{ margin:0px 0px 0px 0px; } .builder-item--primary-menu .nav-ul > li:not(:last-of-type){ margin-right:33px; } .builder-item--primary-menu .style-full-height .nav-ul li:not(.menu-item-nav-search):not(.menu-item-nav-cart) > a:after{ left:-16.5px;right:-16.5px } .builder-item--primary-menu .style-full-height .nav-ul li:not(.menu-item-nav-search):not(.menu-item-nav-cart):hover > a:after{ width: calc(100% + 33px); } .builder-item--primary-menu .nav-ul li a, .builder-item--primary-menu .neve-mm-heading span{ min-height: 19px; } .builder-item--primary-menu{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px;padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } .builder-item--primary-menu svg{ width: 1em;height: 1em; } .builder-item--header_search_responsive input[type=submit],.builder-item--header_search_responsive .nv-search-icon-wrap{ width: 14px; } .builder-item--header_search_responsive .nv-nav-search .search-form input[type=search]{ height: 40px; font-size: 14px;padding-right:50px;border-width:1px 1px 1px 1px;border-radius:1px 1px 1px 1px; } .builder-item--header_search_responsive .nv-search-icon-wrap .nv-icon svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive .close-responsive-search svg{ width: 14px;height: 14px; } .builder-item--header_search_responsive{ padding:0px 10px 0px 10px;margin:0px 0px 0px 0px; } .builder-item--footer-menu .nav-ul > li:not(:last-of-type){ margin-right:14px; } .builder-item--footer-menu .style-full-height .nav-ul#footer-menu > li > a:after{ left:-7px;right:-7px } .builder-item--footer-menu .style-full-height .nav-ul#footer-menu > li:hover > a:after{ width: calc(100% + 14px); } .builder-item--footer-menu .nav-ul a{ min-height: 25px; } .builder-item--footer-menu li > a{ font-size: 1em; line-height: 1.6em; letter-spacing: 0px; } .builder-item--footer-menu li > a svg{ width: 1em;height: 1em; } .builder-item--footer-menu{ padding:0px 0px 0px 0px;margin:0px 0px 0px 0px; } }.nv-content-wrap .elementor a:not(.button):not(.wp-block-file__button){ text-decoration: none; }:root{--nv-primary-accent:#0077ff;--nv-secondary-accent:#0e509a;--nv-site-bg:#ffffff;--nv-light-bg:#ededed;--nv-dark-bg:#14171c;--nv-text-color:#393939;--nv-text-dark-bg:#ffffff;--nv-c-1:#77b978;--nv-c-2:#f37262;--nv-fallback-ff:Arial, Helvetica, sans-serif;}
:root{--e-global-color-nvprimaryaccent:#0077ff;--e-global-color-nvsecondaryaccent:#0e509a;--e-global-color-nvsitebg:#ffffff;--e-global-color-nvlightbg:#ededed;--e-global-color-nvdarkbg:#14171c;--e-global-color-nvtextcolor:#393939;--e-global-color-nvtextdarkbg:#ffffff;--e-global-color-nvc1:#77b978;--e-global-color-nvc2:#f37262;}
</style>
<link rel='stylesheet' id='jetpack_css-css' href='https://c0.wp.com/p/jetpack/11.5.1/css/jetpack.css' type='text/css' media='all' />
<script type='text/javascript' src='https://c0.wp.com/c/6.1.1/wp-includes/js/jquery/jquery.min.js' id='jquery-core-js'></script>
<script type='text/javascript' src='https://c0.wp.com/c/6.1.1/wp-includes/js/jquery/jquery-migrate.min.js' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/adfoxly/public/js/adfoxly-public.js?ver=1.7.91' id='adfoxly-public-js'></script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/adfoxly/public/js/adfoxly-public-ajax.js?ver=1.7.91' id='adfoxly+ajax-js'></script>
<link rel="https://api.w.org/" href="https://srmnotesadda.in/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://srmnotesadda.in/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://srmnotesadda.in/wp-includes/wlwmanifest.xml" />
<meta name="generator" content="WordPress 6.1.1" />
<script type="text/javascript">
           var adfoxlyAjax = {"ajax_url":"\/wp-admin\/admin-ajax.php"};
         </script><script type="application/ld+json">{"@context":"https:\/\/schema.org","@type":"WebSite","name":"SRMnotesADDA","url":"https:\/\/srmnotesadda.in","potentialAction":[{"@type":"SearchAction","target":"https:\/\/srmnotesadda.in\/?s={search_term_string}","query-input":"required name=search_term_string"}]}</script><script type="application/ld+json">{"@context":"https:\/\/schema.org","@type":"BreadcrumbList","itemListElement":[{"@type":"ListItem","position":1,"item":{"@id":"https:\/\/srmnotesadda.in\/","name":"Home"}}]}</script> <style>img#wpstats{display:none}</style>
<script>
			document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );
		</script>
<style>
			.no-js img.lazyload { display: none; }
			figure.wp-block-image img.lazyloading { min-width: 150px; }
							.lazyload, .lazyloading { opacity: 0; }
				.lazyloaded {
					opacity: 1;
					transition: opacity 400ms;
					transition-delay: 0ms;
				}
					</style>
<meta name="onesignal" content="wordpress-plugin" />
<script>

      window.OneSignal = window.OneSignal || [];

      OneSignal.push( function() {
        OneSignal.SERVICE_WORKER_UPDATER_PATH = "OneSignalSDKUpdaterWorker.js.php";
                      OneSignal.SERVICE_WORKER_PATH = "OneSignalSDKWorker.js.php";
                      OneSignal.SERVICE_WORKER_PARAM = { scope: "/" };
        OneSignal.setDefaultNotificationUrl("https://srmnotesadda.in");
        var oneSignal_options = {};
        window._oneSignalInitOptions = oneSignal_options;

        oneSignal_options['wordpress'] = true;
oneSignal_options['appId'] = 'aa3b80ec-161d-4f18-ab60-f77aabc466cb';
oneSignal_options['allowLocalhostAsSecureOrigin'] = true;
oneSignal_options['welcomeNotification'] = { };
oneSignal_options['welcomeNotification']['title'] = "";
oneSignal_options['welcomeNotification']['message'] = "";
oneSignal_options['path'] = "https://srmnotesadda.in/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/";
oneSignal_options['safari_web_id'] = "web.onesignal.auto.4d68c5e3-f56f-4052-bfb7-4c135295bfe6";
oneSignal_options['promptOptions'] = { };
oneSignal_options['promptOptions']['siteName'] = "https://srmnotesadda.in/";
oneSignal_options['notifyButton'] = { };
oneSignal_options['notifyButton']['enable'] = true;
oneSignal_options['notifyButton']['position'] = 'bottom-left';
oneSignal_options['notifyButton']['theme'] = 'default';
oneSignal_options['notifyButton']['size'] = 'medium';
oneSignal_options['notifyButton']['showCredit'] = true;
oneSignal_options['notifyButton']['text'] = {};
                OneSignal.init(window._oneSignalInitOptions);
                OneSignal.showSlidedownPrompt();      });

      function documentInitOneSignal() {
        var oneSignal_elements = document.getElementsByClassName("OneSignal-prompt");

        var oneSignalLinkClickHandler = function(event) { OneSignal.push(['registerForPushNotifications']); event.preventDefault(); };        for(var i = 0; i < oneSignal_elements.length; i++)
          oneSignal_elements[i].addEventListener('click', oneSignalLinkClickHandler, false);
      }

      if (document.readyState === 'complete') {
           documentInitOneSignal();
      }
      else {
           window.addEventListener("load", function(event){
               documentInitOneSignal();
          });
      }
    </script>
<style id="wpsp-style-frontend"></style>
<link rel="icon" href="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-srmnotesadda-1-32x32.png" sizes="32x32" />
<link rel="icon" href="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-srmnotesadda-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-srmnotesadda-1-180x180.png" />
<meta name="msapplication-TileImage" content="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-srmnotesadda-1-270x270.png" />
<style type="text/css" id="wp-custom-css">
			.NR-Ads { position: fixed; bottom: 0px; left: 0; width: 100%; min-height: 70px; max-height: 90px; padding: 5px 5px; box-shadow: 0 -6px 18px 0 rgba(9,32,76,.1); -webkit-transition: all .1s ease-in; transition: all .1s ease-in; display: flex; align-items: center; justify-content: center; background-color: #fefefe; z-index: 20; } 
 
.NR-Ads-close { width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; border-radius: 12px 0 0; position: absolute; right: 0; top: -30px; background-color: #fefefe; box-shadow: 0 -6px 18px 0 rgba(9,32,76,.08); } 
 
.NR-Ads .NR-Ads-close svg { width: 22px; height: 22px; fill: #000; } 
 
.NR-Ads .NR-Ads-content { overflow: hidden; display: block; position: relative; height: 70px; width: 100%; margin-right: 10px; margin-left: 10px; }		</style>
</head>
<body data-rsssl=1 class="error404 wp-custom-logo wp-schema-pro-2.5.2  nv-sidebar-right menu_sidebar_slide_left elementor-default elementor-kit-8" id="neve_body">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-dark-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0.49803921568627" /><feFuncG type="table" tableValues="0 0.49803921568627" /><feFuncB type="table" tableValues="0 0.49803921568627" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-grayscale"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.54901960784314 0.98823529411765" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.71764705882353 0.25490196078431" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-red"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 1" /><feFuncG type="table" tableValues="0 0.27843137254902" /><feFuncB type="table" tableValues="0.5921568627451 0.27843137254902" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-midnight"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0 0" /><feFuncG type="table" tableValues="0 0.64705882352941" /><feFuncB type="table" tableValues="0 1" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-magenta-yellow"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.78039215686275 1" /><feFuncG type="table" tableValues="0 0.94901960784314" /><feFuncB type="table" tableValues="0.35294117647059 0.47058823529412" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-purple-green"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.65098039215686 0.40392156862745" /><feFuncG type="table" tableValues="0 1" /><feFuncB type="table" tableValues="0.44705882352941 0.4" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 0 0" width="0" height="0" focusable="false" role="none" style="visibility: hidden; position: absolute; left: -9999px; overflow: hidden;"><defs><filter id="wp-duotone-blue-orange"><feColorMatrix color-interpolation-filters="sRGB" type="matrix" values=" .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 .299 .587 .114 0 0 " /><feComponentTransfer color-interpolation-filters="sRGB"><feFuncR type="table" tableValues="0.098039215686275 1" /><feFuncG type="table" tableValues="0 0.66274509803922" /><feFuncB type="table" tableValues="0.84705882352941 0.41960784313725" /><feFuncA type="table" tableValues="1 1" /></feComponentTransfer><feComposite in2="SourceGraphic" operator="in" /></filter></defs></svg><div class="wrapper">
<header class="header">
<a class="neve-skip-link show-on-focus" href="#content">
Skip to content </a>
<div id="header-grid" class="hfg_header site-header">
<div class="header--row header-top hide-on-mobile hide-on-tablet layout-full-contained header--row" data-row-id="top" data-show-on="desktop">
<div class="header--row-inner header-top-inner">
<div class="container">
<div class="row row--wrapper" data-section="hfg_header_layout_top">
<div class="builder-item hfg-item-last hfg-item-first col-8 desktop-left offset-4"><div class="item--inner builder-item--logo" data-section="title_tagline" data-item-id="logo">
<div class="site-logo">
<a class="brand" href="https://srmnotesadda.in/" title="SRMnotesADDA" aria-label="SRMnotesADDA"><div class="title-with-logo"><div class="nv-title-tagline-wrap"></div><img width="1400" height="350" src="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line.png" class="neve-site-logo skip-lazy" alt="" decoding="async" data-variant="logo" srcset="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line.png 1400w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-300x75.png 300w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-1024x256.png 1024w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-768x192.png 768w" sizes="(max-width: 1400px) 100vw, 1400px" /></div></a></div>
</div>
</div> </div>
</div>
</div>
</div>
<div class="header--row header-bottom hide-on-mobile hide-on-tablet layout-full-contained header--row" data-row-id="bottom" data-show-on="desktop">
<div class="header--row-inner header-bottom-inner">
<div class="container">
<div class="row row--wrapper" data-section="hfg_header_layout_bottom">
<div class="builder-item has-nav hfg-item-first col-9 desktop-left"><div class="item--inner builder-item--primary-menu has_menu" data-section="header_menu_primary" data-item-id="primary-menu">
<div class="nv-nav-wrap">
<div role="navigation" class="nav-menu-primary style-full-height m-style" aria-label="Primary Menu">
<ul id="nv-primary-navigation-bottom" class="primary-menu-ul nav-ul menu-"><li id="menu-item-113" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-113"><a href="https://srmnotesadda.in/">HOME</a></li>
<li id="menu-item-1265" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-1265"><a href="https://srmnotesadda.in/category/1-year-elab-codes/"><span class="menu-item-title-wrap dd-title">1 Year Elab Codes</span><div role="none" tabindex="-1" class="caret-wrap 2" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li id="menu-item-1563" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1563"><a href="#"><span class="menu-item-title-wrap dd-title">Level 1</span><div role="none" tabindex="-1" class="caret-wrap 3" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li id="menu-item-1269" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1269"><a href="https://srmnotesadda.in/first-year-elab-level-1-i-2021/">First Year ELAB Level 1 (i) (2021)</a></li>
<li id="menu-item-1268" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1268"><a href="https://srmnotesadda.in/first-year-elab-level-1-ii-2021/">First Year Elab Level 1 (ii) (2021)</a></li>
<li id="menu-item-1482" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1482"><a href="https://srmnotesadda.in/first-year-elab-level-1-iii-2021/">First Year Elab Level 1 (iii) (2021)</a></li>
</ul>
</li>
<li id="menu-item-1564" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1564"><a href="#"><span class="menu-item-title-wrap dd-title">Level 2</span><div role="none" tabindex="-1" class="caret-wrap 7" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li id="menu-item-1267" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1267"><a href="https://srmnotesadda.in/first-year-elab-level-2-2021/">First Year Elab Level 2 (2021)</a></li>
<li id="menu-item-1557" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1557"><a href="https://srmnotesadda.in/first-year-elab-level-2-i-2021/">First Year Elab Level 2 (i) (2021)</a></li>
<li id="menu-item-1605" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1605"><a href="https://srmnotesadda.in/first-year-elab-level-2-ii-2021/">First Year Elab Level 2 (ii) (2021)</a></li>
<li id="menu-item-1612" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1612"><a href="https://srmnotesadda.in/first-year-elab-level-2-iii-2021/">First Year Elab Level 2 (iii) (2021)</a></li>
</ul>
</li>
<li id="menu-item-1565" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1565"><a href="#"><span class="menu-item-title-wrap dd-title">Level 3</span><div role="none" tabindex="-1" class="caret-wrap 12" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li id="menu-item-1266" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1266"><a href="https://srmnotesadda.in/first-year-elab-level-3-2021/">First Year Elab Level 3 (2021)</a></li>
</ul>
</li>
<li id="menu-item-290" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-290"><a href="https://srmnotesadda.in/pps-elab/">PPS Elab 1</a></li>
<li id="menu-item-268" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-268"><a href="https://srmnotesadda.in/pps-elab-2/">PPS Elab 2</a></li>
</ul>
</li>
<li id="menu-item-1224" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1224"><a href="https://srmnotesadda.in/2-year-elab-codes/"><span class="menu-item-title-wrap dd-title">2 Year Elab Codes</span><div role="none" tabindex="-1" class="caret-wrap 16" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li id="menu-item-1045" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1045"><a href="https://srmnotesadda.in/data-structures-elab/">DS Elab</a></li>
<li id="menu-item-1046" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1046"><a href="https://srmnotesadda.in/srm-elab-oops-codes-2020/">OOPS Elab</a></li>
</ul>
</li>
<li id="menu-item-1786" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1786"><a href="https://srmnotesadda.in/blogs/">SRM Guide</a></li>
<li id="menu-item-1913" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1913"><a href="https://srmnotesadda.in/hackerrank-srm-ccc-all-solutions/">HACKERRANK SRM CCC</a></li>
<li id="menu-item-1571" class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1571"><a href="https://srmnotesadda.in/became-the-contributor/">Contribute here</a></li>
</ul> </div>
</div>
</div>
</div><div class="builder-item hfg-item-last col-2 desktop-right offset-1"><div class="item--inner builder-item--header_search_responsive" data-section="header_search_responsive" data-item-id="header_search_responsive">
<div class="nv-search-icon-component">
<div class="menu-item-nav-search canvas">
<a aria-label="Search" href="#" class="nv-icon nv-search">
<svg width="15" height="15" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" /></svg>
</a> <div class="nv-nav-search" aria-label="search">
<div class="form-wrap container responsive-search">
<form role="search" method="get" class="search-form" action="https://srmnotesadda.in/">
<label>
<span class="screen-reader-text">Search for...</span>
</label>
<input type="search" class="search-field" aria-label="Search" placeholder="Search for your Question...." value="" name="s" />
<button type="submit" class="search-submit nv-submit" aria-label="Search">
<span class="nv-search-icon-wrap">
<span class="nv-icon nv-search">
<svg width="15" height="15" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" /></svg>
</span></span>
</button>
</form>
</div>
<div class="close-container container responsive-search">
<button class="close-responsive-search" aria-label="Close">
<svg width="50" height="50" viewBox="0 0 20 20" fill="#555555"><path d="M14.95 6.46L11.41 10l3.54 3.54l-1.41 1.41L10 11.42l-3.53 3.53l-1.42-1.42L8.58 10L5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z" /></svg>
</button>
</div>
</div>
</div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
<div class="header--row header-top hide-on-desktop layout-full-contained header--row" data-row-id="top" data-show-on="mobile">
<div class="header--row-inner header-top-inner">
<div class="container">
<div class="row row--wrapper" data-section="hfg_header_layout_top">
<div class="builder-item hfg-item-last hfg-item-first col-12 mobile-center tablet-left"><div class="item--inner builder-item--logo" data-section="title_tagline" data-item-id="logo">
<div class="site-logo">
<a class="brand" href="https://srmnotesadda.in/" title="SRMnotesADDA" aria-label="SRMnotesADDA"><div class="title-with-logo"><div class="nv-title-tagline-wrap"></div><img width="1400" height="350" src="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line.png" class="neve-site-logo skip-lazy" alt="" decoding="async" data-variant="logo" srcset="https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line.png 1400w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-300x75.png 300w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-1024x256.png 1024w, https://srmnotesadda.in/wp-content/uploads/2020/09/cropped-Tag-line-768x192.png 768w" sizes="(max-width: 1400px) 100vw, 1400px" /></div></a></div>
</div>
</div> </div>
</div>
</div>
</div>
<div class="header--row header-bottom hide-on-desktop layout-full-contained header--row" data-row-id="bottom" data-show-on="mobile">
<div class="header--row-inner header-bottom-inner">
<div class="container">
<div class="row row--wrapper" data-section="hfg_header_layout_bottom">
<div class="builder-item hfg-item-first col-4 mobile-left tablet-right"><div class="item--inner builder-item--nav-icon" data-section="header_menu_icon" data-item-id="nav-icon">
<div class="menu-mobile-toggle item-button navbar-toggle-wrapper">
<button type="button" class=" navbar-toggle" value="Navigation Menu" aria-label="Navigation Menu ">
<span class="bars">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</span>
<span class="screen-reader-text">Navigation Menu</span>
</button>
</div> 
</div>
</div><div class="builder-item hfg-item-last col-4 tablet-left mobile-right offset-4"><div class="item--inner builder-item--header_search_responsive" data-section="header_search_responsive" data-item-id="header_search_responsive">
<div class="nv-search-icon-component">
<div class="menu-item-nav-search canvas">
<a aria-label="Search" href="#" class="nv-icon nv-search">
<svg width="15" height="15" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" /></svg>
</a> <div class="nv-nav-search" aria-label="search">
<div class="form-wrap container responsive-search">

<form role="search" method="get" class="search-form" action="https://srmnotesadda.in/">
<label>
<span class="screen-reader-text">Search for...</span>
</label>
<input type="search" class="search-field" aria-label="Search" placeholder="Search for your Question...." value="" name="s" />
<button type="submit" class="search-submit nv-submit" aria-label="Search">
<span class="nv-search-icon-wrap">
<span class="nv-icon nv-search">
<svg width="15" height="15" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" /></svg>
</span></span>
</button>
</form>
</div>
<div class="close-container container responsive-search">
<button class="close-responsive-search" aria-label="Close">
<svg width="50" height="50" viewBox="0 0 20 20" fill="#555555"><path d="M14.95 6.46L11.41 10l3.54 3.54l-1.41 1.41L10 11.42l-3.53 3.53l-1.42-1.42L8.58 10L5.05 6.47l1.42-1.42L10 8.58l3.54-3.53z" /></svg>
</button>
</div>
</div>
</div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
<div id="header-menu-sidebar" class="header-menu-sidebar menu-sidebar-panel slide_left" data-row-id="sidebar">
<div id="header-menu-sidebar-bg" class="header-menu-sidebar-bg">
<div class="close-sidebar-panel navbar-toggle-wrapper">
<button type="button" class="hamburger is-active  navbar-toggle active" value="Navigation Menu" aria-label="Navigation Menu ">
<span class="bars">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</span>
<span class="screen-reader-text">
Navigation Menu </span>
</button>
</div>
<div id="header-menu-sidebar-inner" class="header-menu-sidebar-inner ">
<div class="builder-item has-nav hfg-item-last hfg-item-first col-12 mobile-left tablet-left desktop-left"><div class="item--inner builder-item--primary-menu has_menu" data-section="header_menu_primary" data-item-id="primary-menu">
<div class="nv-nav-wrap">
<div role="navigation" class="nav-menu-primary style-full-height m-style" aria-label="Primary Menu">
<ul id="nv-primary-navigation-sidebar" class="primary-menu-ul nav-ul menu-"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-113"><a href="https://srmnotesadda.in/">HOME</a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-1265"><a href="https://srmnotesadda.in/category/1-year-elab-codes/"><span class="menu-item-title-wrap dd-title">1 Year Elab Codes</span><div role="none" tabindex="0" class="caret-wrap 2" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1563"><a href="#"><span class="menu-item-title-wrap dd-title">Level 1</span><div role="none" tabindex="0" class="caret-wrap 3" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1269"><a href="https://srmnotesadda.in/first-year-elab-level-1-i-2021/">First Year ELAB Level 1 (i) (2021)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1268"><a href="https://srmnotesadda.in/first-year-elab-level-1-ii-2021/">First Year Elab Level 1 (ii) (2021)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1482"><a href="https://srmnotesadda.in/first-year-elab-level-1-iii-2021/">First Year Elab Level 1 (iii) (2021)</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1564"><a href="#"><span class="menu-item-title-wrap dd-title">Level 2</span><div role="none" tabindex="0" class="caret-wrap 7" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1267"><a href="https://srmnotesadda.in/first-year-elab-level-2-2021/">First Year Elab Level 2 (2021)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1557"><a href="https://srmnotesadda.in/first-year-elab-level-2-i-2021/">First Year Elab Level 2 (i) (2021)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1605"><a href="https://srmnotesadda.in/first-year-elab-level-2-ii-2021/">First Year Elab Level 2 (ii) (2021)</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1612"><a href="https://srmnotesadda.in/first-year-elab-level-2-iii-2021/">First Year Elab Level 2 (iii) (2021)</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1565"><a href="#"><span class="menu-item-title-wrap dd-title">Level 3</span><div role="none" tabindex="0" class="caret-wrap 12" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1266"><a href="https://srmnotesadda.in/first-year-elab-level-3-2021/">First Year Elab Level 3 (2021)</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-290"><a href="https://srmnotesadda.in/pps-elab/">PPS Elab 1</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-268"><a href="https://srmnotesadda.in/pps-elab-2/">PPS Elab 2</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1224"><a href="https://srmnotesadda.in/2-year-elab-codes/"><span class="menu-item-title-wrap dd-title">2 Year Elab Codes</span><div role="none" tabindex="0" class="caret-wrap 16" style="margin-left:5px;"><span class="caret"><svg aria-label="Dropdown" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M207.029 381.476L12.686 187.132c-9.373-9.373-9.373-24.569 0-33.941l22.667-22.667c9.357-9.357 24.522-9.375 33.901-.04L224 284.505l154.745-154.021c9.379-9.335 24.544-9.317 33.901.04l22.667 22.667c9.373 9.373 9.373 24.569 0 33.941L240.971 381.476c-9.373 9.372-24.569 9.372-33.942 0z" /></svg></span></div></a>
<ul class="sub-menu">
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1045"><a href="https://srmnotesadda.in/data-structures-elab/">DS Elab</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1046"><a href="https://srmnotesadda.in/srm-elab-oops-codes-2020/">OOPS Elab</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-1786"><a href="https://srmnotesadda.in/blogs/">SRM Guide</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1913"><a href="https://srmnotesadda.in/hackerrank-srm-ccc-all-solutions/">HACKERRANK SRM CCC</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-post menu-item-1571"><a href="https://srmnotesadda.in/became-the-contributor/">Contribute here</a></li>
</ul> </div>
</div>
</div>
</div> </div>
</div>
</div>
<div class="header-menu-sidebar-overlay hfg-ov"></div>
</div>
</header>
<main id="content" class="neve-main">
<div class="container archive-container"><div class="row"><div class="nv-index-posts blog col"><div class="col-12 nv-content-none-wrap"><p>It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.</p><div class="nv-seach-form-wrap">
<form role="search" method="get" class="search-form" action="https://srmnotesadda.in/">
<label>
<span class="screen-reader-text">Search for...</span>
</label>
<input type="search" class="search-field" aria-label="Search" placeholder="Search for..." value="" name="s" />
<button type="submit" class="search-submit nv-submit" aria-label="Search">
<span class="nv-search-icon-wrap">
<span class="nv-icon nv-search">
<svg width="15" height="15" viewBox="0 0 1792 1792" xmlns="http://www.w3.org/2000/svg"><path d="M1216 832q0-185-131.5-316.5t-316.5-131.5-316.5 131.5-131.5 316.5 131.5 316.5 316.5 131.5 316.5-131.5 131.5-316.5zm512 832q0 52-38 90t-90 38q-54 0-90-38l-343-342q-179 124-399 124-143 0-273.5-55.5t-225-150-150-225-55.5-273.5 55.5-273.5 150-225 225-150 273.5-55.5 273.5 55.5 225 150 150 225 55.5 273.5q0 220-124 399l343 343q37 37 37 90z" /></svg>
</span></span>
</button>
</form>
</div></div><div class="w-100"></div></div></div></div>
</main>
<footer class="site-footer" id="site-footer">
<div class="hfg_footer">
<div class="footer--row footer-bottom layout-full-contained" id="cb-row--footer-bottom" data-row-id="bottom" data-show-on="desktop">
<div class="footer--row-inner footer-bottom-inner footer-content-wrap">
<div class="container">
<div class="hfg-grid nv-footer-content hfg-grid-bottom row--wrapper row " data-section="hfg_footer_layout_bottom">
<div class="builder-item hfg-item-last hfg-item-first col-7 desktop-right tablet-left mobile-left offset-5"><div class="item--inner builder-item--footer-menu has_menu" data-section="footer_menu_primary" data-item-id="footer-menu">
<div class="component-wrap">
<div role="navigation" class="style-plain nav-menu-footer" aria-label="Footer Menu">
<ul id="footer-menu" class="footer-menu nav-ul"><li id="menu-item-1144" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-1144"><a href="https://srmnotesadda.in/">HOME</a></li>
<li id="menu-item-1142" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1142"><a href="https://srmnotesadda.in/disclaimer/">Disclaimer</a></li>
<li id="menu-item-1143" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1143"><a href="https://srmnotesadda.in/privacy-policy/">Privacy Policy</a></li>
<li id="menu-item-1777" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1777"><a href="https://srmnotesadda.in/faq/">FAQ</a></li>
</ul> </div>
</div>
</div>
</div> </div>
</div>
</div>
</div>
</div>
</footer>
</div>
<div id="wpfront-scroll-top-container">
<img alt="Back to Top" data-src="https://srmnotesadda.in/wp-content/plugins/wpfront-scroll-top/images/icons/12.png" class="lazyload" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" /><noscript><img src="https://srmnotesadda.in/wp-content/plugins/wpfront-scroll-top/images/icons/12.png" alt="Back to Top" /></noscript> </div>
<script type="text/javascript">
            function wpfront_scroll_top_init() {
                if (typeof wpfront_scroll_top === "function" && typeof jQuery !== "undefined") {
                    wpfront_scroll_top({"scroll_offset":100,"button_width":0,"button_height":0,"button_opacity":0.8,"button_fade_duration":200,"scroll_duration":400,"location":1,"marginX":20,"marginY":20,"hide_iframe":false,"auto_hide":true,"auto_hide_after":2,"button_action":"top","button_action_element_selector":"","button_action_container_selector":"html, body","button_action_element_offset":0});
                } else {
                    setTimeout(wpfront_scroll_top_init, 100);
                }
            }
            wpfront_scroll_top_init();
        </script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/wpfront-scroll-top/js/wpfront-scroll-top.min.js?ver=2.0.7.08086' id='wpfront-scroll-top-js'></script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/ad-invalid-click-protector/assets/js/js.cookie.min.js?ver=3.0.0' id='js-cookie-js'></script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/ad-invalid-click-protector/assets/js/jquery.iframetracker.min.js?ver=2.1.0' id='js-iframe-tracker-js'></script>
<script type='text/javascript' id='aicp-js-extra'>
/* <![CDATA[ */
var AICP = {"ajaxurl":"https:\/\/srmnotesadda.in\/wp-admin\/admin-ajax.php","nonce":"ed296b58e4","ip":"103.255.232.154","clickLimit":"2","clickCounterCookieExp":"24","banDuration":"7","countryBlockCheck":"No","banCountryList":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/ad-invalid-click-protector/assets/js/aicp.min.js?ver=1.0' id='aicp-js'></script>
<script type='text/javascript' id='neve-script-js-extra'>
/* <![CDATA[ */
var NeveProperties = {"ajaxurl":"https:\/\/srmnotesadda.in\/wp-admin\/admin-ajax.php","nonce":"1afeb3997e","isRTL":"","isCustomize":""};
/* ]]> */
</script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/themes/neve/assets/js/build/modern/frontend.js?ver=3.4.4' id='neve-script-js' async></script>
<script type='text/javascript' id='neve-script-js-after'>
	var html = document.documentElement;
	var theme = html.getAttribute('data-neve-theme') || 'light';
	var variants = {"logo":{"light":{"src":"https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line.png","srcset":"https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line.png 1400w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-300x75.png 300w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-1024x256.png 1024w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-768x192.png 768w","sizes":"(max-width: 1400px) 100vw, 1400px"},"dark":{"src":"https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line.png","srcset":"https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line.png 1400w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-300x75.png 300w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-1024x256.png 1024w, https:\/\/srmnotesadda.in\/wp-content\/uploads\/2020\/09\/cropped-Tag-line-768x192.png 768w","sizes":"(max-width: 1400px) 100vw, 1400px"},"same":true}};

	function setCurrentTheme( theme ) {
		var pictures = document.getElementsByClassName( 'neve-site-logo' );
		for(var i = 0; i<pictures.length; i++) {
			var picture = pictures.item(i);
			if( ! picture ) {
				continue;
			};
			var fileExt = picture.src.slice((Math.max(0, picture.src.lastIndexOf(".")) || Infinity) + 1);
			if ( fileExt === 'svg' ) {
				picture.removeAttribute('width');
				picture.removeAttribute('height');
				picture.style = 'width: var(--maxwidth)';
			}
			var compId = picture.getAttribute('data-variant');
			if ( compId && variants[compId] ) {
				var isConditional = variants[compId]['same'];
				if ( theme === 'light' || isConditional || variants[compId]['dark']['src'] === false ) {
					picture.src = variants[compId]['light']['src'];
					picture.srcset = variants[compId]['light']['srcset'] || '';
					picture.sizes = variants[compId]['light']['sizes'];
					continue;
				};
				picture.src = variants[compId]['dark']['src'];
				picture.srcset = variants[compId]['dark']['srcset'] || '';
				picture.sizes = variants[compId]['dark']['sizes'];
			};
		};
	};

	var observer = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			if (mutation.type == 'attributes') {
				theme = html.getAttribute('data-neve-theme');
				setCurrentTheme(theme);
			};
		});
	});

	observer.observe(html, {
		attributes: true
	});
</script>
<script type='text/javascript' src='https://srmnotesadda.in/wp-content/plugins/wp-smushit/app/assets/js/smush-lazy-load.min.js?ver=3.12.3' id='smush-lazy-load-js'></script>
<script type='text/javascript' src='https://cdn.onesignal.com/sdks/OneSignalSDK.js?ver=6.1.1' async='async' id='remote_sdk-js'></script>
<script src='https://stats.wp.com/e-202247.js' defer></script>
<script>
		_stq = window._stq || [];
		_stq.push([ 'view', {v:'ext',blog:'182630788',post:'0',tz:'0',srv:'srmnotesadda.in',j:'1:11.5.1'} ]);
		_stq.push([ 'clickTrackerInit', '182630788', '0' ]);
	</script> <script type="text/javascript" id="wpsp-script-frontend"></script>
</body>
</html>
